import React, { useState, useCallback, useRef } from 'react';
import { Grid } from 'lucide-react';
import { 
  ReactGrid, 
  Column, 
  Row,
  CellChange,
  TextCell,
  DefaultCellTypes,
  Id,
} from "@silevis/reactgrid";
import "@silevis/reactgrid/styles.css";

interface SpreadsheetProps {
  rows: number;
  cols: number;
}

const getColumnLabel = (index: number) => {
  let label = '';
  while (index >= 0) {
    label = String.fromCharCode(65 + (index % 26)) + label;
    index = Math.floor(index / 26) - 1;
  }
  return label;
};

const Spreadsheet: React.FC<SpreadsheetProps> = ({ rows, cols }) => {
  const gridRef = useRef<HTMLDivElement>(null);
  const [cells, setCells] = useState<TextCell[][]>(() => {
    const headerRow: TextCell[] = [
      { type: 'text', text: '' } as TextCell,
      ...Array(cols).fill(null).map((_, i) => ({
        type: 'text',
        text: getColumnLabel(i),
        className: 'header-cell'
      }))
    ];

    const dataRows: TextCell[][] = Array(rows).fill(null).map((_, rowIndex) => [
      { type: 'text', text: `${rowIndex + 1}`, className: 'row-header' } as TextCell,
      ...Array(cols).fill(null).map(() => ({
        type: 'text',
        text: '',
        className: 'data-cell'
      }))
    ]);

    return [headerRow, ...dataRows];
  });

  const [dropTarget, setDropTarget] = useState<{ rowId: Id, columnId: Id } | null>(null);

  const getRows = useCallback((): Row[] => {
    return cells.map((row, idx) => ({
      rowId: idx,
      height: idx === 0 ? 35 : 30,
      cells: row.map(cell => ({
        ...cell,
        className: `${cell.className} ${
          dropTarget && 
          dropTarget.rowId === idx && 
          dropTarget.columnId === cells[0].indexOf(cell) 
            ? 'drop-target' 
            : ''
        }`
      }))
    }));
  }, [cells, dropTarget]);

  const getColumns = useCallback((): Column[] => {
    return Array(cols + 1).fill(null).map((_, idx) => ({
      columnId: idx,
      width: idx === 0 ? 50 : 120
    }));
  }, [cols]);

  const handleChanges = (changes: CellChange<DefaultCellTypes>[]) => {
    setCells(prevCells => {
      const newCells = [...prevCells];
      changes.forEach(change => {
        const changeRowIdx = change.rowId as number;
        const changeColumnIdx = change.columnId as number;
        newCells[changeRowIdx][changeColumnIdx] = {
          ...change.newCell,
          className: 'data-cell'
        } as TextCell;
      });
      return newCells;
    });
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const text = e.dataTransfer.getData('text/plain');
    
    if (dropTarget && dropTarget.rowId > 0 && dropTarget.columnId > 0) {
      setCells(prevCells => {
        const newCells = [...prevCells];
        newCells[dropTarget.rowId as number][dropTarget.columnId as number] = {
          type: 'text',
          text,
          className: 'data-cell'
        };
        return newCells;
      });
    }
    setDropTarget(null);
  };

  const getCellFromPoint = (x: number, y: number) => {
    const grid = gridRef.current;
    if (!grid) return null;

    const cells = grid.getElementsByClassName('rg-cell');
    let targetCell: Element | null = null;
    let minDistance = Infinity;

    // Find the closest cell to the mouse position
    for (const cell of cells) {
      const rect = cell.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      const distance = Math.sqrt(
        Math.pow(x - centerX, 2) + Math.pow(y - centerY, 2)
      );

      if (distance < minDistance) {
        minDistance = distance;
        targetCell = cell;
      }
    }

    if (targetCell) {
      // Get row and column indices from the cell's position in the grid
      const gridRect = grid.getBoundingClientRect();
      const cellRect = targetCell.getBoundingClientRect();
      const rowId = Math.floor((cellRect.top - gridRect.top) / 30);
      const columnId = Math.floor((cellRect.left - gridRect.left) / 120);

      // Adjust for header row
      if (rowId > 0 && columnId > 0) {
        return { rowId, columnId };
      }
    }

    return null;
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const target = getCellFromPoint(e.clientX, e.clientY);
    
    if (target && target.rowId > 0 && target.columnId > 0 && 
        target.rowId <= rows && target.columnId <= cols) {
      setDropTarget(target);
    } else {
      setDropTarget(null);
    }
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    // Only clear dropTarget if we're actually leaving the grid
    const rect = e.currentTarget.getBoundingClientRect();
    if (
      e.clientX <= rect.left ||
      e.clientX >= rect.right ||
      e.clientY <= rect.top ||
      e.clientY >= rect.bottom
    ) {
      setDropTarget(null);
    }
  };

  return (
    <div 
      className="h-full flex flex-col"
      onDrop={handleDrop}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      ref={gridRef}
    >
      <div className="bg-gray-800 text-white p-2 text-sm flex items-center gap-2">
        <Grid className="w-4 h-4" />
        Spreadsheet
      </div>
      <div className="flex-1 overflow-auto">
        <style>
          {`
            .rg-cell {
              border: 1px solid #e5e7eb;
              padding: 0 8px;
              display: flex;
              align-items: center;
            }
            .header-cell {
              background-color: #f3f4f6;
              font-weight: 600;
            }
            .row-header {
              background-color: #f3f4f6;
              justify-content: center;
              font-weight: 500;
            }
            .data-cell {
              background-color: white;
            }
            .data-cell:focus {
              background-color: #eff6ff;
              outline: 2px solid #3b82f6;
              outline-offset: -2px;
            }
            .drop-target {
              background-color: #dbeafe !important;
              outline: 2px dashed #3b82f6 !important;
              outline-offset: -2px;
            }
          `}
        </style>
        <ReactGrid 
          rows={getRows()} 
          columns={getColumns()} 
          onCellsChanged={handleChanges}
        />
      </div>
    </div>
  );
};

export default Spreadsheet;