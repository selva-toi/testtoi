import React from 'react';

interface TextEditorProps {
  value: string;
  onChange: (value: string) => void;
}

const TextEditor: React.FC<TextEditorProps> = ({ value, onChange }) => {
  const handleDragStart = (e: React.DragEvent<HTMLDivElement>, text: string) => {
    e.dataTransfer.setData('text/plain', text);
  };

  const handleSelect = () => {
    const selection = window.getSelection();
    if (selection && selection.toString()) {
      // Make the selected text draggable
      const range = selection.getRangeAt(0);
      const span = document.createElement('span');
      span.draggable = true;
      span.textContent = selection.toString();
      range.surroundContents(span);
    }
  };

  return (
    <div className="h-full flex flex-col">
      <div className="bg-gray-800 text-white p-2 text-sm">Text Editor</div>
      <textarea
        className="flex-1 p-4 bg-gray-50 font-mono text-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onMouseUp={handleSelect}
        onDragStart={(e) => {
          const selection = window.getSelection();
          if (selection) {
            handleDragStart(e, selection.toString());
          }
        }}
      />
    </div>
  );
};

export default TextEditor;