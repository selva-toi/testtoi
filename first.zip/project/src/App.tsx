import React, { useState } from 'react';
import TextEditor from './components/TextEditor';
import Spreadsheet from './components/Spreadsheet';
import { Github } from 'lucide-react';

function App() {
  const [text, setText] = useState('Welcome to the Text Editor!\n\nTry selecting some text and dragging it to a cell in the spreadsheet.');

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-xl font-semibold text-gray-900">Text Editor + Spreadsheet</h1>
          <a
            href="https://github.com/yourusername/text-editor-spreadsheet"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
          >
            <Github className="w-5 h-5" />
            <span>View on GitHub</span>
          </a>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto px-4 py-6 w-full">
        <div className="bg-white rounded-lg shadow-sm h-[calc(100vh-8rem)] flex">
          <div className="w-1/2 border-r">
            <TextEditor value={text} onChange={setText} />
          </div>
          <div className="w-1/2">
            <Spreadsheet rows={20} cols={10} />
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;