import React, { useRef, useState } from 'react';
import { Editor } from '@tinymce/tinymce-react';
import { HotTable } from '@handsontable/react';
import { registerAllModules } from 'handsontable/registry';
import { FileText, Grid } from 'lucide-react';
import 'handsontable/dist/handsontable.full.min.css';

// Register Handsontable modules
registerAllModules();

function App() {
  const editorRef = useRef<any>(null);
  const hotRef = useRef<any>(null);
  const [data, setData] = useState<string[][]>([
    ['', '', '', '', ''],
    ['', '', '', '', ''],
    ['', '', '', '', ''],
    ['', '', '', '', ''],
    ['', '', '', '', '']
  ]);

  const handleEditorInit = (evt: any, editor: any) => {
    editorRef.current = editor;

    editor.on('dragstart', function(e: any) {
      const content = editor.selection.getContent();
      e.dataTransfer.setData('text/plain', editor.selection.getContent({ format: 'text' }));
      e.dataTransfer.setData('text/html', content);
      
      // Enhanced drag ghost
      const dragGhost = document.createElement('div');
      dragGhost.className = 'drag-ghost';
      dragGhost.innerHTML = content;
      document.body.appendChild(dragGhost);
      e.dataTransfer.setDragImage(dragGhost, 10, 10);
      
      setTimeout(() => document.body.removeChild(dragGhost), 0);
    });

    editor.on('mousedown', function(e: any) {
      if (editor.selection.getContent().length > 0) {
        const node = editor.selection.getNode();
        if (node) {
          node.draggable = true;
        }
      }
    });

    editor.on('dragend', function() {
      const node = editor.selection.getNode();
      if (node) {
        node.draggable = false;
      }
    });

    editor.on('drop', function(e: any) {
      e.preventDefault();
      return false;
    });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    const target = e.target as HTMLElement;
    if (target.closest('td')) {
      target.closest('td')!.classList.add('drop-active');
    }
  };

  const handleDragLeave = (e: React.DragEvent) => {
    const target = e.target as HTMLElement;
    if (target.closest('td')) {
      target.closest('td')!.classList.remove('drop-active');
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const target = e.target as HTMLElement;
    const td = target.closest('td');
    
    if (td) {
      td.classList.remove('drop-active');
      const htmlContent = e.dataTransfer.getData('text/html');
      
      const hot = hotRef.current.hotInstance;
      const coords = hot.getCoords(td);
      
      if (coords) {
        const newData = [...data];
        newData[coords.row][coords.col] = htmlContent;
        setData(newData);
        hot.render();

        // Add success feedback
        td.style.backgroundColor = '#dcfce7';
        setTimeout(() => {
          td.style.backgroundColor = '';
        }, 500);
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">Interactive Text Editor & Spreadsheet</h1>
        <div className="flex gap-6">
          {/* TinyMCE Editor */}
          <div className="w-1/2">
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="p-4 bg-gray-50 border-b border-gray-200 flex items-center gap-2">
                <FileText className="w-5 h-5 text-blue-600" />
                <h2 className="font-semibold text-gray-700">Text Editor</h2>
              </div>
              <div className="h-[600px]">
                <Editor
                  apiKey="umlcktoyftl0cz2629lk9bpmuimkw62gkxwqn3ne9am0umjv"
                  onInit={handleEditorInit}
                  initialValue="<p>👋 Welcome! Try these steps:</p><ol><li>Select some text in this editor</li><li>Drag the selected text</li><li>Drop it into any cell in the spreadsheet</li></ol><p>Here's some sample text to try: <strong>Drag me to the spreadsheet!</strong> And some <em>italic text</em> with <span style='color: #2563eb;'>blue color</span>!</p>"
                  init={{
                    height: '100%',
                    menubar: false,
                    plugins: [
                      'advlist', 'autolink', 'lists', 'link', 'charmap',
                      'anchor', 'searchreplace', 'visualblocks',
                      'insertdatetime', 'wordcount'
                    ],
                    toolbar: 'undo redo | blocks | ' +
                      'bold italic forecolor | alignleft aligncenter ' +
                      'alignright alignjustify | bullist numlist',
                    content_style: 'body { font-family:Inter,system-ui,-apple-system,sans-serif; font-size:14px; cursor: text; }',
                    draggable_modal: false,
                    object_resizing: false,
                    resize: false,
                    statusbar: false,
                    browser_spellcheck: true,
                    contextmenu: false,
                    paste_data_images: false,
                    paste_as_text: true
                  }}
                />
              </div>
            </div>
          </div>

          {/* Handsontable Spreadsheet */}
          <div className="w-1/2">
            <div 
              className="bg-white rounded-xl shadow-lg overflow-hidden"
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <div className="p-4 bg-gray-50 border-b border-gray-200 flex items-center gap-2">
                <Grid className="w-5 h-5 text-blue-600" />
                <h2 className="font-semibold text-gray-700">Spreadsheet</h2>
              </div>
              <div className="p-4 h-[600px]">
                <HotTable
                  ref={hotRef}
                  data={data}
                  colHeaders={true}
                  rowHeaders={true}
                  height="100%"
                  licenseKey="non-commercial-and-evaluation"
                  contextMenu={true}
                  columnSorting={true}
                  filters={true}
                  dropdownMenu={true}
                  className="htCustom"
                  renderer={function(instance, td, row, col, prop, value) {
                    if (value && value.includes('<')) {
                      td.innerHTML = value;
                    } else {
                      td.textContent = value;
                    }
                    return td;
                  }}
                  afterChange={(changes) => {
                    if (changes) {
                      const [row, col, , newValue] = changes[0];
                      const newData = [...data];
                      newData[row][col] = newValue;
                      setData(newData);
                    }
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;