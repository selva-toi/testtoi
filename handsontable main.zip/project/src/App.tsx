import React, { useRef, useState } from 'react';
import { Editor } from '@tinymce/tinymce-react';
import { HotTable } from '@handsontable/react';
import { registerAllModules } from 'handsontable/registry';
import 'handsontable/dist/handsontable.full.min.css';

// Register Handsontable modules
registerAllModules();

function App() {
  const editorRef = useRef<any>(null);
  const hotRef = useRef<any>(null);
  const [data, setData] = useState<string[][]>([
    ['', '', '', '', ''],
    ['', '', '', '', ''],
    ['', '', '', '', ''],
    ['', '', '', '', ''],
    ['', '', '', '', '']
  ]);

  const handleEditorInit = (evt: any, editor: any) => {
    editorRef.current = editor;

    // Enable draggable content in TinyMCE
    editor.on('dragstart', function(e: any) {
      // Get the selected content with formatting
      const content = editor.selection.getContent();
      e.dataTransfer.setData('text/plain', editor.selection.getContent({ format: 'text' }));
      e.dataTransfer.setData('text/html', content);
      
      // Add visual feedback
      const dragGhost = document.createElement('div');
      dragGhost.className = 'bg-white p-2 rounded shadow-lg';
      dragGhost.innerHTML = content;
      dragGhost.style.position = 'absolute';
      dragGhost.style.left = '-9999px';
      document.body.appendChild(dragGhost);
      e.dataTransfer.setDragImage(dragGhost, 0, 0);
      
      setTimeout(() => document.body.removeChild(dragGhost), 0);
    });

    // Make content draggable
    editor.on('mousedown', function(e: any) {
      if (editor.selection.getContent().length > 0) {
        const node = editor.selection.getNode();
        if (node) {
          node.draggable = true;
        }
      }
    });

    // Reset draggable state after drag
    editor.on('dragend', function() {
      const node = editor.selection.getNode();
      if (node) {
        node.draggable = false;
      }
    });

    // Prevent default drag behavior inside editor
    editor.on('drop', function(e: any) {
      e.preventDefault();
      return false;
    });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    const target = e.target as HTMLElement;
    if (target.closest('td')) {
      target.closest('td')!.style.backgroundColor = '#e5edff';
    }
  };

  const handleDragLeave = (e: React.DragEvent) => {
    const target = e.target as HTMLElement;
    if (target.closest('td')) {
      target.closest('td')!.style.backgroundColor = '';
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const target = e.target as HTMLElement;
    const td = target.closest('td');
    
    if (td) {
      td.style.backgroundColor = '';
      const content = e.dataTransfer.getData('text/plain');
      
      const hot = hotRef.current.hotInstance;
      const coords = hot.getCoords(td);
      
      if (coords) {
        const newData = [...data];
        newData[coords.row][coords.col] = content;
        setData(newData);
        hot.render();
      }
    }
  };

  return (
    <div className="flex h-screen bg-gray-100">
      {/* TinyMCE Editor */}
      <div className="w-1/2 p-4">
        <div className="bg-white rounded-lg shadow-lg h-full">
          <Editor
            apiKey="umlcktoyftl0cz2629lk9bpmuimkw62gkxwqn3ne9am0umjv"
            onInit={handleEditorInit}
            initialValue="<p>Select some text and drag it to a cell in the spreadsheet. Try selecting this text and dragging it!</p>"
            init={{
              height: '100%',
              menubar: false,
              plugins: [
                'advlist', 'autolink', 'lists', 'link', 'charmap',
                'anchor', 'searchreplace', 'visualblocks',
                'insertdatetime', 'wordcount'
              ],
              toolbar: 'undo redo | blocks | ' +
                'bold italic forecolor | alignleft aligncenter ' +
                'alignright alignjustify | bullist numlist',
              content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:14px; cursor: text; }',
              draggable_modal: false,
              object_resizing: false,
              resize: false,
              statusbar: false,
              browser_spellcheck: true,
              contextmenu: false,
              paste_data_images: false,
              paste_as_text: true
            }}
          />
        </div>
      </div>

      {/* Handsontable Spreadsheet */}
      <div className="w-1/2 p-4">
        <div 
          className="bg-white rounded-lg shadow-lg p-4 h-full"
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <HotTable
            ref={hotRef}
            data={data}
            colHeaders={true}
            rowHeaders={true}
            height="100%"
            licenseKey="non-commercial-and-evaluation"
            contextMenu={true}
            columnSorting={true}
            filters={true}
            dropdownMenu={true}
            afterChange={(changes) => {
              if (changes) {
                const [row, col, , newValue] = changes[0];
                const newData = [...data];
                newData[row][col] = newValue;
                setData(newData);
              }
            }}
          />
        </div>
      </div>
    </div>
  );
}

export default App;