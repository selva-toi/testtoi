"use client"

import { useRef, useState } from "react"
import { ReactGrid, type Column, type Row, type CellChange, type TextCell } from "@silevis/reactgrid"
import "@silevis/reactgrid/styles.css"

interface SpreadsheetCell extends TextCell {
  type: "text"
  text: string
}

export function Spreadsheet() {
  const [rows, setRows] = useState<Row[]>(() => {
    // Initialize with 50 rows and 10 columns
    return Array.from({ length: 50 }, (_, rowIndex) => ({
      rowId: rowIndex,
      cells: Array.from({ length: 10 }, (_, colIndex) => ({
        type: "text",
        text: rowIndex === 0 && colIndex === 0 ? "Drag text here from the editor" : "",
        className: rowIndex === 0 && colIndex === 0 ? "text-muted-foreground italic" : "",
      })),
    }))
  })

  const [columns] = useState<Column[]>(() =>
    Array.from({ length: 10 }, (_, i) => ({
      columnId: i,
      width: 150,
    })),
  )

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    const text = e.dataTransfer.getData("text/plain")

    // Get the drop position relative to the grid
    const gridRect = e.currentTarget.getBoundingClientRect()
    const x = e.clientX - gridRect.left
    const y = e.clientY - gridRect.top

    // Find the closest cell to the drop position
    const columnWidth = 150 // matches our column width
    const rowHeight = 30 // default ReactGrid row height
    const col = Math.floor(x / columnWidth)
    const row = Math.floor(y / rowHeight)

    // Update the cell with the dropped text
    const newRows = [...rows]
    if (newRows[row] && newRows[row].cells[col]) {
      newRows[row].cells[col] = {
        type: "text",
        text: text,
        className: "",
      }
      setRows(newRows)
    }
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
  }

  const handleChanges = (changes: CellChange[]) => {
    setRows((prevRows) => {
      const newRows = [...prevRows]
      changes.forEach((change) => {
        const changeRowIdx = change.rowId as number
        const changeColumnIdx = change.columnId as number
        newRows[changeRowIdx].cells[changeColumnIdx] = {
          type: "text",
          text: change.newCell.text,
          className: "",
        }
      })
      return newRows
    })
  }

  return (
    <div className="h-full p-4" onDrop={handleDrop} onDragOver={handleDragOver}>
      <div style={{ height: "calc(100vh - 120px)" }}>
        <ReactGrid rows={rows} columns={columns} onCellsChanged={handleChanges} />
      </div>
    </div>
  )
}

