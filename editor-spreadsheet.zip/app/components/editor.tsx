"use client"

import { Editor as TinyMCEEditor } from "@tinymce/tinymce-react"
import { useRef } from "react"

export function Editor() {
  const editorRef = useRef<any>(null)

  const handleDragStart = (e: React.DragEvent) => {
    const selection = editorRef.current?.editor?.selection
    if (selection) {
      const content = selection.getContent()
      e.dataTransfer.setData("text/plain", content)
    }
  }

  return (
    <div className="h-full p-4">
      <TinyMCEEditor
        apiKey={process.env.NEXT_PUBLIC_TINYMCE_API_KEY}
        onInit={(evt, editor) => {
          editorRef.current = editor
        }}
        init={{
          height: "100%",
          menubar: true,
          readonly: false,
          inline: false,
          entity_encoding: "raw",
          verify_html: false,
          forced_root_block: "p",
          plugins: [
            "advlist",
            "autolink",
            "lists",
            "link",
            "image",
            "charmap",
            "preview",
            "anchor",
            "searchreplace",
            "visualblocks",
            "code",
            "fullscreen",
            "insertdatetime",
            "media",
            "table",
            "code",
            "help",
            "wordcount",
          ],
          toolbar:
            "undo redo | blocks | " +
            "bold italic forecolor | alignleft aligncenter " +
            "alignright alignjustify | bullist numlist outdent indent | " +
            "removeformat | help",
          content_style: "body { font-family:Helvetica,Arial,sans-serif; font-size:14px }",
          setup: (editor) => {
            editor.on("dragstart", handleDragStart)
          },
          init_instance_callback: (editor) => {
            editor.setContent("Type or paste content here and drag it to the spreadsheet.")
          },
        }}
      />
    </div>
  )
}

