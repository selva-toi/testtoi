"use client"

import { Editor } from "./components/editor"
import { SpreadsheetComponent } from "./components/spreadsheet"

export default function Page() {
  return (
    <div className="flex h-screen flex-col">
      <header className="border-b p-4 text-center">
        <h1 className="text-2xl font-bold">TinyMCE + Spreadsheet</h1>
        <p className="text-sm text-muted-foreground">Select text in the editor and drag it to the spreadsheet</p>
      </header>
      <div className="flex flex-1">
        <div className="w-1/2 border-r">
          <div className="p-2 text-sm font-medium">Rich Text Editor</div>
          <Editor />
        </div>
        <div className="w-1/2">
          <div className="p-2 text-sm font-medium">Spreadsheet</div>
          <SpreadsheetComponent />
        </div>
      </div>
    </div>
  )
}

