"use client"

import { forwardRef, useEffect, useState } from "react"
import type GC from "@grapecity/spread-sheets"

interface SpreadSheetWrapperProps {
  workbookInitialized?: (workbook: GC.Spread.Sheets.Workbook) => void
  backColor?: string
  hostStyle?: React.CSSProperties
}

const SpreadSheetWrapper = forwardRef<any, SpreadSheetWrapperProps>(function SpreadSheetWrapper(props, ref) {
  const [Component, setComponent] = useState<any>(null)

  useEffect(() => {
    // Import the spread-sheets-react component
    import("@grapecity/spread-sheets-react").then((module) => {
      // Get the default export which is the Spread component
      if (module.default?.default) {
        setComponent(() => module.default.default)
      } else if (module.default) {
        setComponent(() => module.default)
      }
    })
  }, [])

  if (!Component) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="text-sm text-muted-foreground">Loading spreadsheet...</div>
      </div>
    )
  }

  return (
    <Component
      ref={ref}
      backColor={props.backColor}
      hostStyle={props.hostStyle}
      workbookInitialized={props.workbookInitialized}
    />
  )
})

SpreadSheetWrapper.displayName = "SpreadSheetWrapper"

export { SpreadSheetWrapper }

