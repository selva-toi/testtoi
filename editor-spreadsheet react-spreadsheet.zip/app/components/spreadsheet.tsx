"use client"

import { useRef, useState } from "react"

type Cell = {
  value: string
}

type SpreadsheetData = Cell[][]

export function SpreadsheetComponent() {
  const [data, setData] = useState<SpreadsheetData>(() => {
    // Initialize with 50 rows and 10 columns
    return Array.from({ length: 50 }, (_, rowIndex) =>
      Array.from({ length: 10 }, (_, colIndex) => ({
        value: rowIndex === 0 && colIndex === 0 ? "Drag text here from the editor" : "",
      })),
    )
  })

  const handleCellChange = (rowIndex: number, colIndex: number, value: string) => {
    const newData = [...data]
    newData[rowIndex][colIndex] = { value }
    setData(newData)
  }

  const handleDrop = (e: React.DragEvent, rowIndex: number, colIndex: number) => {
    e.preventDefault()
    const text = e.dataTransfer.getData("text/plain")
    handleCellChange(rowIndex, colIndex, text)
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
  }

  return (
    <div className="h-full p-4">
      <div className="h-[calc(100vh-120px)] overflow-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr>
              {Array.from({ length: 10 }, (_, i) => (
                <th key={i} className="sticky top-0 bg-gray-100 px-4 py-2 text-sm font-medium">
                  {String.fromCharCode(65 + i)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.map((row, rowIndex) => (
              <tr key={rowIndex}>
                {row.map((cell, colIndex) => (
                  <td
                    key={colIndex}
                    className="border border-gray-200 p-2 min-w-[100px] h-[25px]"
                    onDrop={(e) => handleDrop(e, rowIndex, colIndex)}
                    onDragOver={handleDragOver}
                  >
                    <input
                      type="text"
                      value={cell.value}
                      onChange={(e) => handleCellChange(rowIndex, colIndex, e.target.value)}
                      className="w-full h-full bg-transparent focus:outline-none"
                      style={{
                        fontStyle: rowIndex === 0 && colIndex === 0 && !cell.value ? "italic" : "normal",
                        color: rowIndex === 0 && colIndex === 0 && !cell.value ? "#666" : "inherit",
                      }}
                    />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

