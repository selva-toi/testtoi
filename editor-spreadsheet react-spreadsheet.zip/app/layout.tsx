export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <title>TinyMCE + SpreadJS Drag and Drop</title>
      </head>
      <body>
        <main className="min-h-screen bg-background">{children}</main>
      </body>
    </html>
  )
}



import './globals.css'